package git.artdeell.mojo.awt;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;

import com.kdt.LoggerView;

import git.artdeell.mojo.BaseActivity;
import git.artdeell.mojo.CallbackBridge;
import git.artdeell.mojo.Logger;
import git.artdeell.mojo.MojoApplication;
import git.artdeell.mojo.SingleTapConfirm;
import git.artdeell.mojo.Tools;
import git.artdeell.mojo.input.keyboard.TouchCharInput;
import git.artdeell.mojo.game.platform.Platform;
import git.artdeell.mojo.game.platform.backend.AWTBackend;
import git.artdeell.mojo.multirt.MultiRTUtils;
import git.artdeell.mojo.multirt.Runtime;
import git.artdeell.mojo.prefs.LauncherPreferences;
import git.artdeell.mojo.utils.JREUtils;
import git.artdeell.mojo.utils.MathUtils;
import git.artdeell.mojo.utils.jre.JavaRunner;
import git.artdeell.mojo.utils.jre.classfile.ClassFormatException;
import git.artdeell.mojo.utils.jre.classfile.ClassVersionReader;

import org.apache.commons.io.IOUtils;

import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;

import git.artdeell.mojo.R;

public class AWTActivity extends BaseActivity implements View.OnTouchListener {

    private AWTView mTextureView;
    private LoggerView mLoggerView;
    private TouchCharInput mTouchCharInput;

    private LinearLayout mTouchPad;
    private ImageView mMousePointerImageView;
    private GestureDetector mGestureDetector;

    private boolean mIsVirtualMouseEnabled;
    private boolean mIsTrusted;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java_gui_launcher);

        try {
            File latestLogFile = new File(Tools.DIR_GAME_HOME, "latestlog.txt");
            if (!latestLogFile.exists() && !latestLogFile.createNewFile())
                throw new IOException("Failed to create a new log file");
            Logger.begin(latestLogFile.getAbsolutePath());
        }catch (IOException e) {
            Tools.showError(this, e, true);
        }

        mTouchCharInput = findViewById(R.id.awt_touch_char);

        CallbackBridge.windowWidth = AWTView.AWT_CANVAS_WIDTH;
        CallbackBridge.windowHeight = AWTView.AWT_CANVAS_HEIGHT;

        Platform.PLATFORM = new AWTBackend();
        Platform.initializeMinimal(getApplicationContext());

        mTouchPad = findViewById(R.id.main_touchpad);
        mLoggerView = findViewById(R.id.launcherLoggerView);
        mMousePointerImageView = findViewById(R.id.main_mouse_pointer);
        mTextureView = findViewById(R.id.installmod_surfaceview);
        mGestureDetector = new GestureDetector(this, new SingleTapConfirm());
        mTouchPad.setFocusable(false);
        mTouchPad.setVisibility(View.GONE);

        findViewById(R.id.installmod_mouse_pri).setOnTouchListener(this);
        findViewById(R.id.installmod_mouse_sec).setOnTouchListener(this);
        findViewById(R.id.installmod_window_moveup).setOnTouchListener(this);
        findViewById(R.id.installmod_window_movedown).setOnTouchListener(this);
        findViewById(R.id.installmod_window_moveleft).setOnTouchListener(this);
        findViewById(R.id.installmod_window_moveright).setOnTouchListener(this);

        mMousePointerImageView.post(() -> {
            ViewGroup.LayoutParams params = mMousePointerImageView.getLayoutParams();
            params.width = (int) (36 * LauncherPreferences.PREF_MOUSESCALE);
            params.height = (int) (54 * LauncherPreferences.PREF_MOUSESCALE);
        });

        mTouchPad.setOnTouchListener(new View.OnTouchListener() {
            float prevX = 0, prevY = 0;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // MotionEvent reports input details from the touch screen
                // and other input controls. In this case, you are only
                // interested in events where the touch position changed.
                // int index = event.getActionIndex();
                int action = event.getActionMasked();

                float x = event.getX();
                float y = event.getY();
                float mouseX, mouseY;

                mouseX = mMousePointerImageView.getX();
                mouseY = mMousePointerImageView.getY();

                if (mGestureDetector.onTouchEvent(event)) {
                    sendScaledMousePosition(mouseX,mouseY);
                    CallbackBridge.performClick(MotionEvent.BUTTON_PRIMARY);
                } else {
                    if (action == MotionEvent.ACTION_MOVE) { // 2
                        mouseX = Math.max(0, Math.min(v.getWidth(), mouseX + x - prevX));
                        mouseY = Math.max(0, Math.min(v.getHeight(), mouseY + y - prevY));
                        placeMouseAt(mouseX, mouseY);
                        sendScaledMousePosition(mouseX, mouseY);
                    }
                }

                prevY = y;
                prevX = x;
                return true;
            }
        });

        mTextureView.setOnTouchListener((v, event) -> {
            float x = event.getX();
            float y = event.getY();
            if (mGestureDetector.onTouchEvent(event)) {
                sendScaledMousePosition(x + mTextureView.getX(), y);
                CallbackBridge.performClick(MotionEvent.BUTTON_PRIMARY);
                return true;
            }

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_UP: // 1
                case MotionEvent.ACTION_CANCEL: // 3
                case MotionEvent.ACTION_POINTER_UP: // 6
                    break;
                case MotionEvent.ACTION_MOVE: // 2
                    sendScaledMousePosition(x + mTextureView.getX(), y);
                    break;
            }
            return true;
        });

        try {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                finish();
                return;
            }
            mIsTrusted = extras.getBoolean("trusted", false);
            final List<String> javaArgs = extras.getStringArrayList("javaArgs");
            final Uri resourceUri = extras.getParcelable("modUri");
            final String jarPath = extras.getString("modPath");
            if(jarPath != null) {
                File jarFile = new File(jarPath);
                startModInstaller(jarFile, javaArgs);
            }else {
                MojoApplication.sExecutorService.execute(()->startModInstallerWithUri(resourceUri, javaArgs));
            }
            if(extras.getBoolean("openLogOutput", false)) openLogOutput(null);
        } catch (Throwable th) {
            Tools.showError(this, th, true);
        }


        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Tools.dialogForceClose(AWTActivity.this);
            }
        });
    }

    private void startModInstallerWithUri(Uri uri, List<String> javaArgs) {
        if(uri == null) {
            startModInstaller(null, javaArgs);
            return;
        }
        try {
            File cacheFile = new File(getCacheDir(), "mod-installer-temp");
            InputStream contentStream = getContentResolver().openInputStream(uri);
            if(contentStream == null) throw new IOException("Failed to open content stream");
            try (FileOutputStream fileOutputStream = new FileOutputStream(cacheFile)) {
                IOUtils.copy(contentStream, fileOutputStream);
            }
            contentStream.close();
            startModInstaller(cacheFile, javaArgs);
        }catch (IOException e) {
            Tools.showError(this, e, true);
        }
    }

    public Runtime selectRuntime(int javaVersion) {
        if(javaVersion == -1) {
            finalErrorDialog(getString(R.string.execute_jar_failed_to_read_file));
            return null;
        }
        String nearestRuntime = MultiRTUtils.getNearestJreName(javaVersion);
        if(nearestRuntime == null) {
            finalErrorDialog(getString(R.string.multirt_nocompatiblert, javaVersion));
            return null;
        }
        return MultiRTUtils.forceReread(nearestRuntime);
    }

    private static class JarFileProperties {
        public final String mainClass;
        public final int minJavaVersion;

        private JarFileProperties(String mainClass, int minJavaVersion) {
            this.mainClass = mainClass;
            this.minJavaVersion = minJavaVersion;
        }

        public static JarFileProperties read(File file) throws IOException {
            try (JarFile jarFile = new JarFile(file)) {
                Manifest manifest = jarFile.getManifest();
                if(manifest == null) return null;
                Attributes mainAttrs = manifest.getMainAttributes();
                if(mainAttrs == null) return null;
                String mainClass = mainAttrs.getValue("Main-Class");
                if(mainClass == null) return null;
                int javaVersion = getJavaVersion(jarFile, mainClass);
                return new JarFileProperties(mainClass, javaVersion);
            }
        }
    }

    private void runModInstaller(File modFile, List<String> javaArgs) {
        JarFileProperties jarFileProperties = null;
        try {
            jarFileProperties = JarFileProperties.read(modFile);
        }catch (IOException e) {
            Log.i("JavaGUILauncherActivity", "Failed to read JarFileProperties", e);
        }
        if(jarFileProperties == null) {
            finalErrorDialog(getString(R.string.execute_jar_failed_to_read_file));
            return;
        }
        Runtime selectedRuntime = selectRuntime(jarFileProperties.minJavaVersion);
        launchJavaRuntime(selectedRuntime, javaArgs,  modFile, jarFileProperties.mainClass);
    }

    private void startModInstaller(File modFile, List<String> javaArgs) {
        new Thread(() -> runModInstaller(modFile, javaArgs), "JREMainThread").start();
    }

    private void finalErrorDialog(CharSequence msg) {
        runOnUiThread(()-> new AlertDialog.Builder(this)
                .setTitle(R.string.global_error)
                .setMessage(msg)
                .setPositiveButton(android.R.string.ok, (d,w)->this.finish())
                .setCancelable(false)
                .show());
    }

    @Override
    public void onResume() {
        super.onResume();
        final int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
        final View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(uiOptions);
    }



    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent e) {
        boolean isDown;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: // 0
            case MotionEvent.ACTION_POINTER_DOWN: // 5
                isDown = true;
                break;
            case MotionEvent.ACTION_UP: // 1
            case MotionEvent.ACTION_CANCEL: // 3
            case MotionEvent.ACTION_POINTER_UP: // 6
                isDown = false;
                break;
            default:
                return false;
        }
        
        switch (v.getId()) {
            case R.id.installmod_mouse_pri:
                Platform.sendMouseButtonEvent(MotionEvent.BUTTON_PRIMARY, isDown ? 1 : 0, CallbackBridge.getCurrentMods());
                break;
                
            case R.id.installmod_mouse_sec:
                Platform.sendMouseButtonEvent(MotionEvent.BUTTON_SECONDARY, isDown ? 1 : 0, CallbackBridge.getCurrentMods());
                break;
        }
        if(isDown) switch(v.getId()) {
            case R.id.installmod_window_moveup:
                AWTBridge.nativeMoveWindow(0, -10);
                break;
            case R.id.installmod_window_movedown:
                AWTBridge.nativeMoveWindow(0, 10);
                break;
            case R.id.installmod_window_moveleft:
                AWTBridge.nativeMoveWindow(-10, 0);
                break;
            case R.id.installmod_window_moveright:
                AWTBridge.nativeMoveWindow(10, 0);
                break;
        }
        return true;
    }

    public void placeMouseAt(float x, float y) {
        mMousePointerImageView.setX(x);
        mMousePointerImageView.setY(y);
    }

    @SuppressWarnings("SuspiciousNameCombination")
    void sendScaledMousePosition(float x, float y){
        // Clamp positions to the borders of the usable view, then scale them
        x = androidx.core.math.MathUtils.clamp(x, 0, mTextureView.getWidth());
        y = androidx.core.math.MathUtils.clamp(y, 0, mTextureView.getHeight());

        Platform.cursorX = (int) MathUtils.map(x, 0, mTextureView.getWidth(), 0, CallbackBridge.windowWidth);
        Platform.cursorY = (int) MathUtils.map(y, 0, mTextureView.getHeight(), 0, CallbackBridge.windowHeight);
        // There's no grab on AWT
        Platform.PLATFORM.sendMousePosition(Platform.cursorX, Platform.cursorY, false);
    }

    public void forceClose(View v) {
        Tools.dialogForceClose(this);
    }

    public void openLogOutput(View v) {
        mLoggerView.setVisibility(View.VISIBLE);
    }

    public void toggleVirtualMouse(View v) {
        mIsVirtualMouseEnabled = !mIsVirtualMouseEnabled;
        mTouchPad.setVisibility(mIsVirtualMouseEnabled ? View.VISIBLE : View.GONE);
        if(mIsVirtualMouseEnabled && mMousePointerImageView.getX() == 0 && mMousePointerImageView.getY() == 0) {
            mTouchPad.post(()->placeMouseAt(mTouchPad.getWidth() / 2f, mTouchPad.getHeight() / 2f));
        }
        Toast.makeText(this,
                mIsVirtualMouseEnabled ? R.string.control_mouseon : R.string.control_mouseoff,
                Toast.LENGTH_SHORT).show();
    }

    public void launchJavaRuntime(Runtime runtime, List<String> javaArgs, File modFile, String mainClass) {
        JREUtils.redirectAndPrintJRELog();
        try {
            List<String> javaArgList = new ArrayList<>();

            if(javaArgs != null) {
                javaArgList.addAll(javaArgs);
            }
            
            if (LauncherPreferences.PREF_JAVA_SANDBOX && !mIsTrusted) {
                Collections.reverse(javaArgList);
                javaArgList.add("-Xbootclasspath/a:" + Tools.DIR_DATA + "/security/pro-grade.jar");
                javaArgList.add("-Djava.security.manager=net.sourceforge.prograde.sm.ProGradeJSM");
                javaArgList.add("-Djava.security.policy=" + Tools.DIR_DATA + "/security/java_sandbox.policy");
                Collections.reverse(javaArgList);
            }

            Logger.appendToLog("Info: Java arguments: " + javaArgList);

            JavaRunner.nativeSetupExit(this.getApplicationContext());
            JavaRunner.startJvm(runtime, javaArgList, Collections.singletonList(modFile.getAbsolutePath()), mainClass, Collections.emptyList());

            Tools.fullyExit();
        } catch (Throwable th) {
            Tools.showError(this, th, true);
        }
    }

    public void toggleKeyboard(View view) {
        mTouchCharInput.switchKeyboardState();
    }

    public void performCopy(View view) {
        CallbackBridge.setModifiers(KeyEvent.KEYCODE_CTRL_LEFT, true);
        Platform.PLATFORM.sendKeyEvent(KeyEvent.KEYCODE_CTRL_LEFT, 1, CallbackBridge.getCurrentMods());
        CallbackBridge.sendKeyPress(KeyEvent.KEYCODE_C);
        Platform.PLATFORM.sendKeyEvent(KeyEvent.KEYCODE_CTRL_LEFT, 0, CallbackBridge.getCurrentMods());
        CallbackBridge.setModifiers(KeyEvent.KEYCODE_CTRL_LEFT, false);
    }

    public void performPaste(View view) {
        CallbackBridge.setModifiers(KeyEvent.KEYCODE_CTRL_LEFT, true);
        Platform.PLATFORM.sendKeyEvent(KeyEvent.KEYCODE_CTRL_LEFT, 1, CallbackBridge.getCurrentMods());
        CallbackBridge.sendKeyPress(KeyEvent.KEYCODE_V);
        Platform.PLATFORM.sendKeyEvent(KeyEvent.KEYCODE_CTRL_LEFT, 0, CallbackBridge.getCurrentMods());
        CallbackBridge.setModifiers(KeyEvent.KEYCODE_CTRL_LEFT, false);
    }

    private static int getJavaVersion(JarFile jarFile, String mainClass) throws IOException {
        mainClass = mainClass.trim().replace('.', '/') + ".class";
        ZipEntry mainClassFile = jarFile.getEntry(mainClass);
        if (mainClassFile == null) return -1;

        try (InputStream classStream = jarFile.getInputStream(mainClassFile)) {
            int majorVersion = ClassVersionReader.readClassMajorVersion(classStream);
            return ClassVersionReader.classMajorToVMMajor(majorVersion);
        } catch (ClassFormatException | EOFException ignored) {
            return -1;
        }

    }
}
